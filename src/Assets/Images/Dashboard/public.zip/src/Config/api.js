const API = 'http://localhost:5000/api/';
export default API;