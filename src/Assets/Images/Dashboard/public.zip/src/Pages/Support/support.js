import React,{ Component} from 'react'

function Support() 
{
    return (
    <>
       Support
    </>
    );
}
export default Support;