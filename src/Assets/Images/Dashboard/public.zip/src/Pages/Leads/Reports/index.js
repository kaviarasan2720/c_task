import React,{ Component} from 'react'

function Lead_reports() 
{
    return (
    <>
       Lead reports
    </>
    );
}
export default Lead_reports;