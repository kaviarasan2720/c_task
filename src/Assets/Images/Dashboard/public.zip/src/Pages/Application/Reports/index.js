import React,{ Component} from 'react'

function Application_reports() 
{
    return (
    <>
       Application reports
    </>
    );
}
export default Application_reports;