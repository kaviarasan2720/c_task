import React,{ Component} from 'react'
import Applicationchart from './applicationchart'
import Applicationlist from './applicationlist'
function Application() 
{
    return (
    <>
       <Applicationchart />
       <Applicationlist />
    </>
    );
}
export default Application;