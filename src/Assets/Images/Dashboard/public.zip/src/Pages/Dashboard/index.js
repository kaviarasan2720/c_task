import React,{ Component} from 'react'

function Dashboard() 
{
    return (
    <>
       Main Dashboard
    </>
    );
}
export default Dashboard;