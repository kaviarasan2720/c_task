import download_sub from '../../../Assets/Images/Dashboard/download-sub.svg'
import left from '../../../Assets/Images/Dashboard/left.svg'
import right from '../../../Assets/Images/Dashboard/right.svg'

export {download_sub,left,right};