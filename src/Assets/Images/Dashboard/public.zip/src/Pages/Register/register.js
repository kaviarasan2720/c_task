import React,{ Component} from 'react'

function Register() 
{
    return (<div>Register</div>);
}
export default Register;