// import React,{ Component} from 'react'
// import Applicationchart from './applicationchart'
// import Smile from './Smile'
// function Generals() 
// {
//     return (
//     <>
//        <Applicationchart />
//        <Smile />
//     </>
//     );
// }
// export default Generals;