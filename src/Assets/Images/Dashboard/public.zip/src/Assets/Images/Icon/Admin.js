import Total_Leads_Icon from '../Dashboard/total_leads_icon.svg'
import Appointment_Booked_Icon from '../Dashboard/appointment_booked.svg'
import Walkin_Icon  from '../Dashboard/walkin_icon.svg'
import Verified_Leads_Icon from '../Dashboard/verified_leads.svg'
import Opened_Icon from '../Dashboard/verified_leads.svg'
import Unopened_Icon from '../Dashboard/unopened.svg'
import Surgeries_Icon from '../Dashboard/surgeries.svg'


export {Total_Leads_Icon,Appointment_Booked_Icon,Walkin_Icon,Verified_Leads_Icon,Opened_Icon,Unopened_Icon,Surgeries_Icon};