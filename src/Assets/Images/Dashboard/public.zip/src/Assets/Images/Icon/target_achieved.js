import Target_Achive_Icon from "../Dashboard/target_achive_icon.svg"
import Appoinment_Booking_Icon from "../Dashboard/appoinment_booking_icon.svg"
import Walkings_Icon from "../Dashboard/walkings_icon.svg"
import Surgeries_Icon from '../Dashboard/surgeries.svg'

export {Target_Achive_Icon,Appoinment_Booking_Icon,Walkings_Icon,Surgeries_Icon};